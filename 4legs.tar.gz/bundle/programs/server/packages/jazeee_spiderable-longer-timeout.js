(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;

/* Package-scope variables */
var __coffeescriptShare, Spiderable;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/jazeee_spiderable-longer-timeout/lib/spiderable.coffee.js                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                                  // 1
                                                                                                                  //
Spiderable = {};                                                                                                  // 1
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/jazeee_spiderable-longer-timeout/lib/server.coffee.js                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var MAX_BUFFER, PHANTOM_SCRIPT, REQUEST_TIMEOUT_IN_MILLISECONDS, bindEnvironment, cacheCollection, child_process, crypto, querystring, responseHandler, urlParser;
                                                                                                                  //
child_process = Npm.require('child_process');                                                                     // 1
                                                                                                                  //
querystring = Npm.require('querystring');                                                                         // 1
                                                                                                                  //
urlParser = Npm.require('url');                                                                                   // 1
                                                                                                                  //
crypto = Npm.require('crypto');                                                                                   // 1
                                                                                                                  //
cacheCollection = new Mongo.Collection('SpiderableCacheCollection');                                              // 1
                                                                                                                  //
Meteor.startup(function() {                                                                                       // 1
  if (Spiderable.cacheLifetimeInMinutes == null) {                                                                //
    Spiderable.cacheLifetimeInMinutes = 3 * 60;                                                                   //
  }                                                                                                               //
  if (!_.isNumber(Spiderable.cacheLifetimeInMinutes)) {                                                           // 10
    throw new Meteor.Error("Bad Spiderable.cacheLifetimeInMinutes");                                              // 10
  }                                                                                                               //
  return cacheCollection._ensureIndex({                                                                           //
    createdAt: 1                                                                                                  // 11
  }, {                                                                                                            //
    expireAfterSeconds: Spiderable.cacheLifetimeInMinutes * 60,                                                   // 11
    background: true                                                                                              // 11
  });                                                                                                             //
});                                                                                                               // 8
                                                                                                                  //
cacheCollection._ensureIndex({                                                                                    // 1
  hash: 1                                                                                                         // 13
}, {                                                                                                              //
  unique: true,                                                                                                   // 13
  background: true                                                                                                // 13
});                                                                                                               //
                                                                                                                  //
bindEnvironment = Meteor.bindEnvironment(function(callback) {                                                     // 1
  return callback();                                                                                              //
});                                                                                                               // 15
                                                                                                                  //
Spiderable.userAgentRegExps = [/^facebookExternalHit/i, /^linkedinBot/i, /^twitterBot/i, /^googleBot/i, /^bingBot/i, /^yandex/i, /^google-structured-data-testing-tool/i, /^yahoo/i, /^MJ12Bot/i, /^tweetmemeBot/i, /^baiduSpider/i, /^Mail\.RU_Bot/i, /^ahrefsBot/i, /^SiteLockSpider/i];
                                                                                                                  //
Spiderable.allowRedirects = true;                                                                                 // 1
                                                                                                                  //
Spiderable.ignoredRoutes = [];                                                                                    // 1
                                                                                                                  //
Spiderable.debug = false;                                                                                         // 1
                                                                                                                  //
REQUEST_TIMEOUT_IN_MILLISECONDS = 30 * 1000;                                                                      // 1
                                                                                                                  //
MAX_BUFFER = 10 * 1024 * 1024;                                                                                    // 1
                                                                                                                  //
Spiderable._urlForPhantom = function(siteAbsoluteUrl, requestUrl) {                                               // 1
  var escapedFragment, parsedAbsoluteUrl, parsedQuery, parsedUrl;                                                 // 60
  parsedUrl = urlParser.parse(requestUrl);                                                                        // 60
  parsedQuery = querystring.parse(parsedUrl.query);                                                               // 60
  escapedFragment = parsedQuery._escaped_fragment_;                                                               // 60
  delete parsedQuery._escaped_fragment_;                                                                          // 60
  if (Spiderable.customQuery) {                                                                                   // 65
    if (_.isString(Spiderable.customQuery)) {                                                                     // 66
      parsedQuery[Spiderable.customQuery] = 'true';                                                               // 67
    } else if (_.isBoolean(Spiderable.customQuery) && Spiderable.customQuery) {                                   //
      parsedQuery.___isRunningPhantomJS___ = 'true';                                                              // 69
    }                                                                                                             //
  }                                                                                                               //
  parsedAbsoluteUrl = urlParser.parse(siteAbsoluteUrl);                                                           // 60
  if (parsedUrl.pathname.charAt(0) === '/') {                                                                     // 74
    parsedUrl.pathname = parsedUrl.pathname.substring(1);                                                         // 75
  }                                                                                                               //
  parsedAbsoluteUrl.pathname = urlParser.resolve(parsedAbsoluteUrl.pathname, parsedUrl.pathname);                 // 60
  parsedAbsoluteUrl.query = parsedQuery;                                                                          // 60
  parsedAbsoluteUrl.search = null;                                                                                // 60
  if ((escapedFragment != null) && escapedFragment.length > 0) {                                                  // 81
    parsedAbsoluteUrl.hash = '!' + decodeURIComponent(escapedFragment);                                           // 82
  }                                                                                                               //
  return urlParser.format(parsedAbsoluteUrl);                                                                     //
};                                                                                                                // 58
                                                                                                                  //
PHANTOM_SCRIPT = Meteor.rootPath + "/assets/packages/jazeee_spiderable-longer-timeout/lib/phantom_script.js";     // 1
                                                                                                                  //
responseHandler = function(res, result) {                                                                         // 1
  var header, i, len, ref, ref1;                                                                                  // 88
  if (_.isEmpty(result)) {                                                                                        // 88
    result = {};                                                                                                  // 88
  }                                                                                                               //
  if (result.status === null || result.status === 'null') {                                                       // 89
    result.status = 404;                                                                                          // 89
  }                                                                                                               //
  result.status = isNaN(result.status) ? 200 : parseInt(result.status);                                           // 88
  if (((ref = result.headers) != null ? ref.length : void 0) > 0) {                                               // 92
    ref1 = result.headers;                                                                                        // 93
    for (i = 0, len = ref1.length; i < len; i++) {                                                                // 93
      header = ref1[i];                                                                                           //
      if (!/gzip/i.test(header.value)) {                                                                          // 94
        res.setHeader(header.name, header.value);                                                                 // 94
      }                                                                                                           //
    }                                                                                                             // 93
  } else {                                                                                                        //
    res.setHeader('Content-Type', 'text/html');                                                                   // 96
  }                                                                                                               //
  res.writeHead(result.status);                                                                                   // 88
  return res.end(result.content);                                                                                 //
};                                                                                                                // 87
                                                                                                                  //
WebApp.connectHandlers.use(function(req, res, next) {                                                             // 1
  var cached, fullCommand, hash, phantomJsArgs, url;                                                              // 103
  if ((/\?.*_escaped_fragment_=/.test(req.url) || _.any(Spiderable.userAgentRegExps, function(re) {               // 103
    return re.test(req.headers['user-agent']);                                                                    //
  })) && !_.any(Spiderable.ignoredRoutes, function(route) {                                                       //
    return req.url.indexOf(route) > -1;                                                                           //
  })) {                                                                                                           //
    Spiderable.originalRequest = req;                                                                             // 109
    url = Spiderable._urlForPhantom(Meteor.absoluteUrl(), req.url);                                               // 109
    hash = new Buffer(url).toString('base64');                                                                    // 109
    cached = cacheCollection.findOne({                                                                            // 109
      hash: hash                                                                                                  // 112
    });                                                                                                           //
    if (cached) {                                                                                                 // 114
      responseHandler(res, cached);                                                                               // 115
      if (Spiderable.debug) {                                                                                     // 116
        console.info("Spiderable successfully completed [from cache] for url: [" + cached.status + "] " + url);   // 116
      }                                                                                                           //
    } else {                                                                                                      //
      phantomJsArgs = process.env.METEOR_PKG_SPIDERABLE_PHANTOMJS_ARGS;                                           // 123
      if (phantomJsArgs == null) {                                                                                //
        phantomJsArgs = '';                                                                                       //
      }                                                                                                           //
      if (phantomJsArgs.indexOf('--load-images=') === -1) {                                                       // 126
        phantomJsArgs += ' --load-images=no';                                                                     // 127
      }                                                                                                           //
      if (phantomJsArgs.indexOf('--ssl-protocol=') === -1) {                                                      // 133
        phantomJsArgs += ' --ssl-protocol=TLSv1';                                                                 // 134
      }                                                                                                           //
      if (phantomJsArgs.indexOf('--ignore-ssl-errors=') === -1) {                                                 // 136
        phantomJsArgs += ' --ignore-ssl-errors=true';                                                             // 137
      }                                                                                                           //
      if (Spiderable.allowRedirects && phantomJsArgs.indexOf('--web-security=false') === -1) {                    // 139
        phantomJsArgs += ' --web-security=false';                                                                 // 140
      }                                                                                                           //
      fullCommand = "phantomjs " + phantomJsArgs + " " + PHANTOM_SCRIPT + " " + (JSON.stringify(url));            // 123
      return child_process.exec(fullCommand, {                                                                    //
        timeout: REQUEST_TIMEOUT_IN_MILLISECONDS,                                                                 // 145
        maxBuffer: MAX_BUFFER                                                                                     // 145
      }, function(error, stdout, stderr) {                                                                        //
        return bindEnvironment(function() {                                                                       //
          var output;                                                                                             // 150
          if (!error) {                                                                                           // 150
            if (stdout.length) {                                                                                  // 152
              try {                                                                                               // 153
                output = JSON.parse(stdout.replace(/^(?!(\{.*\})$)(.*)|\r\n/gim, ''));                            // 154
                responseHandler(res, output);                                                                     // 154
                if (Spiderable.debug) {                                                                           // 156
                  console.info("Spiderable successfully completed for url: [" + output.status + "] " + url);      // 156
                }                                                                                                 //
                cacheCollection.upsert({                                                                          // 154
                  hash: hash                                                                                      // 157
                }, {                                                                                              //
                  '$set': {                                                                                       // 158
                    hash: hash,                                                                                   // 159
                    url: url,                                                                                     // 159
                    headers: output.headers,                                                                      // 159
                    content: output.content,                                                                      // 159
                    status: output.status,                                                                        // 159
                    createdAt: new Date                                                                           // 159
                  }                                                                                               //
                });                                                                                               //
                return;                                                                                           // 165
              } catch (_error) {                                                                                  //
                error = _error;                                                                                   // 167
                console.error(error, "Probably failed to parse PhantomJS output from: ", stdout);                 // 167
              }                                                                                                   //
            } else {                                                                                              //
              if (Spiderable.debug) {                                                                             // 169
                console.info("Meteor application returned empty response");                                       // 169
              }                                                                                                   //
              return responseHandler(res, {                                                                       // 170
                status: 204,                                                                                      // 170
                content: ''                                                                                       // 170
              });                                                                                                 //
            }                                                                                                     //
          }                                                                                                       //
          if (Spiderable.debug) {                                                                                 // 172
            console.error('Spiderable failed for url: ', url, error, stdout, stderr);                             // 173
          }                                                                                                       //
          if ((error != null ? error.code : void 0) === 127) {                                                    // 174
            console.warn('spiderable: phantomjs not installed. Download and install from http://phantomjs.org/');
          } else {                                                                                                //
            console.error('spiderable: phantomjs failed:', error, '\nstderr:', stderr);                           // 177
          }                                                                                                       //
          return next();                                                                                          //
        });                                                                                                       //
      });                                                                                                         //
    }                                                                                                             //
  } else {                                                                                                        //
    return next();                                                                                                //
  }                                                                                                               //
});                                                                                                               // 100
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jazeee:spiderable-longer-timeout'] = {
  Spiderable: Spiderable
};

})();

//# sourceMappingURL=jazeee_spiderable-longer-timeout.js.map
