(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var lmSocialShare;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ipstas_social-share/packages/ipstas_social-share.js      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ipstas:social-share'] = {
  lmSocialShare: lmSocialShare
};

})();

//# sourceMappingURL=ipstas_social-share.js.map
