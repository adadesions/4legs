(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/gadicohen_phantomjs/packages/gadicohen_phantomjs.js                //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
(function () {                                                                 // 1
                                                                               // 2
////////////////////////////////////////////////////////////////////////////   // 3
//                                                                        //   // 4
// packages/gadicohen:phantomjs/phantom.js                                //   // 5
//                                                                        //   // 6
////////////////////////////////////////////////////////////////////////////   // 7
                                                                          //   // 8
var phantomjs = Npm.require('phantomjs-sun'), path = Npm.require('path'); // 1
process.env.PATH += ':' + path.dirname(phantomjs.path);                   // 2
                                                                          // 3
////////////////////////////////////////////////////////////////////////////   // 12
                                                                               // 13
}).call(this);                                                                 // 14
                                                                               // 15
/////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gadicohen:phantomjs'] = {};

})();

//# sourceMappingURL=gadicohen_phantomjs.js.map
