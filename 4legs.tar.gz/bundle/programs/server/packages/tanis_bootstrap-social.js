(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/tanis_bootstrap-social/packages/tanis_bootstrap-social.j //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tanis:bootstrap-social'] = {};

})();

//# sourceMappingURL=tanis_bootstrap-social.js.map
