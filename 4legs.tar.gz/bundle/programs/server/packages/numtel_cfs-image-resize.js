(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Random = Package.random.Random;

/* Package-scope variables */
var resizeImageStream;

(function(){

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// packages/numtel_cfs-image-resize/server.js                                //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
                                                                             //
// cfs-image-resize                                                          // 1
// MIT License ben@latenightsketches.com                                     // 2
                                                                             // 3
// Prepare background worker process                                         // 4
var pkgdir = Npm.require('pkgdir');                                          // 5
var fork = Npm.require('child_process').fork;                                // 6
var path = Npm.require('path');                                              // 7
var fs = Npm.require('fs');                                                  // 8
                                                                             // 9
var workerCode = Assets.getText('worker.js');                                // 10
var workerFile =                                                             // 11
  path.join(process.cwd(), 'imageResizeWorker.' + Random.id() + '.js');      // 12
fs.writeFileSync(workerFile, workerCode);                                    // 13
                                                                             // 14
/*                                                                           // 15
Exported method for generating a CollectionFS transformWrite function        // 16
@param  options  object   Object containing paramaters for resize            // 17
@option width    integer  Output width in pixels, required                   // 18
@option height   integer  Output height in pixels, required                  // 19
@option format   string   Output image format. Default: image/png            // 20
@option quality  number   For image format image/jpeg, between 0-100         // 21
*/                                                                           // 22
resizeImageStream = function(options) {                                      // 23
  return function(fileObj, readStream, writeStream) {                        // 24
    var chunks = [];                                                         // 25
                                                                             // 26
    readStream.on('readable', function() {                                   // 27
      // Save each incoming chunk of the read stream                         // 28
      var chunk = readStream.read();                                         // 29
      chunks.push(chunk);                                                    // 30
    });                                                                      // 31
                                                                             // 32
    readStream.on('end', Meteor.bindEnvironment(function() {                 // 33
      // Concatenate all of the chunks together to get the full input buffer
      var input = Buffer.concat(chunks);                                     // 35
                                                                             // 36
      options.format = options.format || fileObj.original.type;              // 37
                                                                             // 38
      var worker = fork(workerFile, [ pkgdir, JSON.stringify(options) ]);    // 39
                                                                             // 40
      worker.send(input);                                                    // 41
                                                                             // 42
      worker.on('message', function(output) {                                // 43
        writeStream.end(new Buffer(output));                                 // 44
        worker.kill();                                                       // 45
      });                                                                    // 46
    }));                                                                     // 47
  }                                                                          // 48
}                                                                            // 49
                                                                             // 50
///////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['numtel:cfs-image-resize'] = {
  resizeImageStream: resizeImageStream
};

})();

//# sourceMappingURL=numtel_cfs-image-resize.js.map
