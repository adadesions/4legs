(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var MediumEditor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mediumeditor_mediumeditor/packages/mediumeditor_mediumed //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mediumeditor:mediumeditor'] = {
  MediumEditor: MediumEditor
};

})();

//# sourceMappingURL=mediumeditor_mediumeditor.js.map
