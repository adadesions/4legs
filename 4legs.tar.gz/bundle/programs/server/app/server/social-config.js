(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/social-config.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
ServiceConfiguration.configurations.remove({                           // 1
    service: 'facebook'                                                // 2
});                                                                    //
                                                                       //
ServiceConfiguration.configurations.insert({                           // 5
    service: 'facebook',                                               // 6
    appId: '1650232795264053',                                         // 7
    secret: 'b121f8fd0cdd123defe16f5050d55a9b'                         // 8
});                                                                    //
                                                                       //
//Test App                                                             //
// ServiceConfiguration.configurations.insert({                        //
//     service: 'facebook',                                            //
//     appId: '1650233041930695',                                      //
//     secret: '30e0f9fb8f8971561dd5a8f229b749b4'                      //
// });                                                                 //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=social-config.js.map
