(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/connection.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.onConnection(function (conn) {                                  // 1
  // console.log(conn.clientAddress);                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=connection.js.map
