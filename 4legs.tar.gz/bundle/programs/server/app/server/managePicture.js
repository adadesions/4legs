(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/managePicture.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  removePicture: function (id) {                                       // 2
    Images.remove({ _id: id });                                        // 3
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=managePicture.js.map
