(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/notificationMethod.js                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  'setAsRead': function () {                                           // 2
    Notify.update({ notifyTo: Meteor.userId(), read: false }, {        // 3
      $set: { read: true }                                             // 4
    }, { multi: true });                                               //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=notificationMethod.js.map
