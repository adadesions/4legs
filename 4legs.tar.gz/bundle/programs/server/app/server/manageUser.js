(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/manageUser.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  updateProfile: function (newData) {                                  // 2
    Meteor.users.update({ _id: this.userId }, {                        // 3
      $set: {                                                          // 4
        "profile.birthday": newData.birthday,                          // 5
        "profile.topics": newData.topics,                              // 6
        "profile.vetInfo": newData.vetObj                              // 7
      }                                                                //
    });                                                                //
                                                                       //
    Accounts.setUsername(this.userId, newData.username);               // 11
  },                                                                   //
                                                                       //
  updateProfilePicture: function (newId) {                             // 14
    Meteor.users.update({ _id: this.userId }, {                        // 15
      $set: {                                                          // 16
        "profile.image._id": newId                                     // 17
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  addFollowing: function (followingId) {                               // 22
    Meteor.users.update({ _id: this.userId }, {                        // 23
      $addToSet: {                                                     // 24
        "profile.following": {                                         // 25
          followingId: followingId,                                    // 26
          followAt: new Date()                                         // 27
        }                                                              //
      }                                                                //
    });                                                                //
    Notify.insert({                                                    // 31
      notifyTo: followingId,                                           // 32
      notifyFrom: Meteor.userId(),                                     // 33
      action: 'following',                                             // 34
      read: false,                                                     // 35
      createdAt: new Date()                                            // 36
    });                                                                //
  },                                                                   //
                                                                       //
  addFollower: function (followingId) {                                // 40
    Meteor.users.update({ _id: followingId }, {                        // 41
      $addToSet: {                                                     // 42
        "profile.followers": {                                         // 43
          followerId: this.userId,                                     // 44
          followerAt: new Date()                                       // 45
        }                                                              //
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  checkFollowing: function (followingId) {                             // 51
    var following = Meteor.user().profile.following;                   // 52
    return _.contains(_.pluck(following, 'followingId'), followingId);
  },                                                                   //
                                                                       //
  unFollowing: function (followingId) {                                // 56
    Meteor.users.update({ _id: this.userId }, {                        // 57
      $pull: {                                                         // 58
        'profile.following': {                                         // 59
          'followingId': followingId                                   // 60
        } }                                                            //
    });                                                                //
  },                                                                   //
                                                                       //
  unFollower: function (followingId) {                                 // 65
    Meteor.users.update({ _id: followingId }, {                        // 66
      $pull: {                                                         // 67
        'profile.followers': {                                         // 68
          'followerId': this.userId                                    // 69
        }                                                              //
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  queryFollowing: function (id) {                                      // 75
    var following = Meteor.users.findOne({ _id: id }),                 // 76
        ids = following.profile.following,                             //
        followingSet = _.map(ids, function (data) {                    //
      return Meteor.users.findOne({ _id: data.followingId });          // 79
    });                                                                //
    return followingSet;                                               // 81
  },                                                                   //
                                                                       //
  verifyIdCard: function (idCardNo, tel) {                             // 84
    var user = Meteor.user();                                          // 85
    if (user.profile.idCardNo) {                                       // 86
      if (user.profile.idCardNo === idCardNo) {                        // 87
        Meteor.users.upsert({ _id: user._id }, {                       // 88
          $set: {                                                      // 89
            'profile.tel': tel                                         // 90
          }                                                            //
        });                                                            //
        return true;                                                   // 93
      } else {                                                         //
        return false;                                                  // 96
      }                                                                //
    } else {                                                           //
      Meteor.users.upsert({ _id: user._id }, {                         // 100
        $set: {                                                        // 101
          'profile.idCardNo': idCardNo,                                // 102
          'profile.tel': tel                                           // 103
        }                                                              //
      });                                                              //
      return true;                                                     // 106
    }                                                                  //
  },                                                                   //
                                                                       //
  updateVetVerify: function (userId, bool) {                           // 110
    Meteor.users.update({ _id: userId }, { $set: { 'profile.vetInfo.verified': bool } });
  },                                                                   //
                                                                       //
  upsertFbAccount: function (_id) {                                    // 114
    Meteor.users.upsert({ _id: _id }, {                                // 115
      $set: {                                                          // 116
        username: Meteor.user().services.facebook.name,                // 117
        emails: [{                                                     // 118
          address: Meteor.user().services.facebook.email,              // 120
          verified: false                                              // 121
        }],                                                            //
        profile: {                                                     // 124
          birthday: "",                                                // 125
          topics: [],                                                  // 126
          vetInfo: "",                                                 // 127
          followers: [],                                               // 128
          following: [],                                               // 129
          asAdmin: { loggedIn: false },                                // 130
          privileged: false                                            // 131
        }                                                              //
      }                                                                //
    });                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=manageUser.js.map
